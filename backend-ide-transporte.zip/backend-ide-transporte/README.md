
# Backend IDE Transporte

Este backend permite actualizar el archivo `BASE_DATOS_TRANSPORTE_2025.geojson` en el repositorio GitHub desde la aplicación web.

## Endpoints

- `POST /subirGeojson`: Recibe un GeoJSON y lo sube al repositorio.
